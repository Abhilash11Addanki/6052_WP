import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shopping-homepage',
  templateUrl: './shopping-homepage.component.html',
  styleUrls: ['./shopping-homepage.component.css']
})
export class ShoppingHomepageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
