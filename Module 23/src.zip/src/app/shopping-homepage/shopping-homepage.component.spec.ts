import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShoppingHomepageComponent } from './shopping-homepage.component';

describe('ShoppingHomepageComponent', () => {
  let component: ShoppingHomepageComponent;
  let fixture: ComponentFixture<ShoppingHomepageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShoppingHomepageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShoppingHomepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
