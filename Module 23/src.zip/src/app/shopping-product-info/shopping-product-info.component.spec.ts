import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShoppingProductInfoComponent } from './shopping-product-info.component';

describe('ShoppingProductInfoComponent', () => {
  let component: ShoppingProductInfoComponent;
  let fixture: ComponentFixture<ShoppingProductInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShoppingProductInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShoppingProductInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
