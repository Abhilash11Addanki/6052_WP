import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShoppingHomepageComponent } from './shopping-homepage/shopping-homepage.component'
import { LoginComponent } from './login/login.component';
import { RegPageComponent } from './reg-page/reg-page.component';
import { ShoppingProductInfoComponent } from './shopping-product-info/shopping-product-info.component';
import { CartComponent } from './cart/cart.component';
import { CheckoutComponent } from './checkout/checkout.component';
const routes: Routes = [
  { path: '', component: ShoppingHomepageComponent},
  { path: 'login', component: LoginComponent},
  { path: 'signup', component: RegPageComponent},
  { path: 'laptop', component: ShoppingProductInfoComponent},
  { path: 'cart', component: CartComponent},
  { path: 'checkout', component: CheckoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComp = [ShoppingHomepageComponent, LoginComponent, RegPageComponent, ShoppingProductInfoComponent, CartComponent, CheckoutComponent]
