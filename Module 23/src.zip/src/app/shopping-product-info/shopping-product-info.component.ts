import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-shopping-product-info',
  templateUrl: './shopping-product-info.component.html',
  styleUrls: ['./shopping-product-info.component.css']
})
export class ShoppingProductInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
