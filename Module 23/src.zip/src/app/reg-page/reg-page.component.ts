import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reg-page',
  templateUrl: './reg-page.component.html',
  styleUrls: ['./reg-page.component.css']
})
export class RegPageComponent implements OnInit {
  password:string;
  x:string;
  firstname:string;
  lastname:string;
  confirmpassword:string;
  submitted:boolean;
  count:number=0;

  constructor() {
    this.submitted=false;
   }

  ngOnInit() {
  }
  checkValid() {
    if(this.password==this.confirmpassword) {
      this.submitted=true;
      this.count+=1;
    } else if (this.password!=this.confirmpassword) {
      alert("To register enter a valid password");
    }
  }
  onSubmit() {
    this.submitted = true;
  }
}
